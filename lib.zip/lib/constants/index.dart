//全局常量
class GlobalConstants {
  static const String BASE_URL = "https://meikou-api.itheima.net";
  static const int TIME_OUT = 10;
  static const String SUCCESS_CODE = "1";
}

class HttpConstants {
  static const String BANNER_LIST = "/home/banner";
  static const String CATEGORY_LIST = "/home/category/head";
}

GlobalConstants globalConstants = GlobalConstants();
