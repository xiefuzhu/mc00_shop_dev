class BannerItem {
  String id;
  String imageUrl;
  BannerItem({required this.id, required this.imageUrl});
  factory BannerItem.fromJson(Map<String, dynamic> json) {
    //网页返回json数据

    return BannerItem(
      id: json['id']?.toString() ?? "", //怎么我代码又变成deadcode了🤢
      imageUrl: json['imageUrl']?.toString() ?? "",
    );
  } //工厂构造函数，接受一个json对象，返回一个BannerItem实例
  //最好能把。。。
}
